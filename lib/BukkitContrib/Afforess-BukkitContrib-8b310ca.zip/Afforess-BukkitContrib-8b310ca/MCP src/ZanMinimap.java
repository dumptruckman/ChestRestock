package net.minecraft.src;
import net.minecraft.client.Minecraft;
public class ZanMinimap implements Runnable {

    public void run() {
    }

    public void OnTickInGame(Minecraft game) {
    }

}