package org.bukkitcontrib.inventory;

import org.bukkit.inventory.PlayerInventory;

public interface ContribPlayerInventory extends PlayerInventory, CraftingInventory, ContribInventory{

}
