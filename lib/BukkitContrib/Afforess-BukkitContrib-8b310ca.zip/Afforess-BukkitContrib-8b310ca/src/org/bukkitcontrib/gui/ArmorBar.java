package org.bukkitcontrib.gui;

import java.util.UUID;

public class ArmorBar extends GenericWidget{

    public ArmorBar() {
        
    }
    
    @Override
    public WidgetType getType() {
        return WidgetType.ArmorBar;
    }
    
    public UUID getId() {
        return new UUID(0, 0);
    }

    @Override
    public void render() {
        // TODO Auto-generated method stub
        
    }

}
