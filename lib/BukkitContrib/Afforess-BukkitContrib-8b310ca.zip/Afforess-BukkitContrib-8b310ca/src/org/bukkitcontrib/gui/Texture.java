package org.bukkitcontrib.gui;

public interface Texture extends Widget {
    
    public String getUrl();
    
    public Texture setUrl(String Url);

}
