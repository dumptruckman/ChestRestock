package org.bukkitcontrib.gui;

public interface SolidBackground {
    
    public void setColor(float red, float green, float blue, float alpha);

}
