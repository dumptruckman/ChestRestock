package org.bukkitcontrib.gui;

public interface Control extends Widget{

}
