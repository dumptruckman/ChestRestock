package org.bukkitcontrib.gui;

public interface Button extends Control, Label{
    
    public HoverState getHoverState();
}
