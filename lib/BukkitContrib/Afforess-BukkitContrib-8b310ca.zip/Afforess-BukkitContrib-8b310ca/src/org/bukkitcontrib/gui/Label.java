package org.bukkitcontrib.gui;

public interface Label extends Widget{
    
    public String getText();
    
    public Label setText(String text);
}
