package org.bukkitcontrib.event.inventory;

public enum InventorySlotType {
    RESULT,
    CRAFTING,
    HELMET,
    ARMOR,
    LEGGINGS,
    BOOTS,
    CONTAINER,
    PACK,
    QUICKBAR,
    OUTSIDE,
    FUEL,
    SMELTING,
}
