package org.bukkit.entity;

/**
 * Represents a Weather related entity, such as a storm
 */
public interface Weather extends Entity {}
