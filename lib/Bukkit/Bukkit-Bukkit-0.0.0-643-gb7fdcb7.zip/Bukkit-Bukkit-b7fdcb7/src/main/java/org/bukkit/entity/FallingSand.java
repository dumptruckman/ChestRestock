/**
 *
 */
package org.bukkit.entity;

/**
 * Represents Falling Sand.
 *
 * @author Cogito
 *
 */
public interface FallingSand extends Entity {}
